'use strict';
const AUTHOR = 'HansS';

var remote = require('electron').remote,
	dialog = require('electron').remote.dialog,
	fs = require('fs'),
	path = require('path'),
	xls = require('xlsjs');
	
function buildBom(data, newHeaders){
	
}